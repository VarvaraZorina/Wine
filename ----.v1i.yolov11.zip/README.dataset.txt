# Вино > 2024-12-08 10:26pm
https://universe.roboflow.com/varya-6wfd8/-ovzbr

Provided by a Roboflow user
License: CC BY 4.0

